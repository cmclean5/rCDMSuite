# CDMSuite.R
#
#' CDMSuite
#'
#' Imports
#' @useDynLib CDMSuite, .registration = TRUE
## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
"_PACKAGE"
