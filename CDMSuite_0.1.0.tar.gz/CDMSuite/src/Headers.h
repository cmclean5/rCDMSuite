#if !defined(HEADERS_INCLUDED)
#define HEADERS_INCLUDED

#include <iostream>
#include <string>
#include <cstring>
#include <vector>  
#include <algorithm>
#include "stdlib.h"
#include <ctime>
#include <cmath>
#include <limits>
#include <fcntl.h>
#include <ctype.h>

//Name spaces
using namespace std;

#endif
