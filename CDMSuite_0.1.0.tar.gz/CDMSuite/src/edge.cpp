#include "edge.h"

edge::edge(){

  target=0;
  K=1;
  weight=0;

}

edge::~edge(){}
